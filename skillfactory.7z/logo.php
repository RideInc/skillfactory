<div class="logo">
  <img src="img/logo.png" alt="< logo />">
</div>
