
<?php
 $h1 = 'приветствую вас';
 $h2 = 'на моей страничке';
?>

<?php
 $name    = 'Сергей';
 $surname = 'Федосеев';
 $school  = 'SkillFactory';
 $city    = 'Москва';
 $age     = 29;
?>


<?php
include 'main.php';
?>
