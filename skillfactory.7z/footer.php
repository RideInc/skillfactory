<div class="footer">
  <p>Copyright © 2023 Sergey Fedoseev</p>
</div>
